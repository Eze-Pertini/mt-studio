/**
 * MT Studio — Traducciones de UI estática
 * Cubre: Navbar, Footer, Contacto, Overview de Servicios.
 * Las traducciones de cada servicio individual viven en services.js (campo `en`).
 */

export const ui = {
  es: {
    nav: {
      home: 'Inicio',
      portfolio: 'Portfolio',
      about: 'Nosotros',
      blog: 'Blog',
      contact: 'Contacto',
      services: 'Servicios',
      seeAll: 'Ver todos los servicios',
      seeAllShort: 'Ver todos →',
      talk: 'Hablemos',
      talkArrow: 'Hablemos →',
    },
    footer: {
      tagline: 'Estudio digital independiente. Creamos experiencias web con diseño premium y tecnología moderna para proyectos que merecen destacar.',
      servicesHeading: 'Servicios',
      studioHeading: 'Studio',
      rights: 'Todos los derechos reservados.',
      madeIn: 'Diseñado y desarrollado en Argentina 🇦🇷',
    },
    contact: {
      badge: 'Contacto',
      titleA: 'Contanos tu',
      titleB: 'proyecto',
      subtitle: 'Sin formularios interminables ni esperas eternas. Te respondemos en menos de 24 horas.',
      formTitle: 'Envianos un mensaje',
      fieldName: 'Nombre *',
      fieldNamePh: 'Tu nombre',
      fieldEmail: 'Email *',
      fieldEmailPh: 'tu@email.com',
      fieldCompany: 'Empresa / Proyecto',
      fieldCompanyPh: 'Nombre de tu empresa o proyecto',
      fieldService: '¿Qué necesitás?',
      serviceSelect: 'Seleccioná un servicio',
      serviceOptions: ['Diseño Web', 'Ecommerce', 'Sistema Web', 'Automatización', 'Mantenimiento Web', 'Otro'],
      fieldMessage: 'Contanos sobre tu proyecto *',
      fieldMessagePh: 'Qué querés hacer, en qué etapa estás, qué resultado esperás...',
      sendBtn: 'Enviar mensaje',
      sending: 'Enviando...',
      whatsappBtn: 'WhatsApp',
      whatsappHint: 'El botón de WhatsApp abre un chat con tus datos precargados.',
      errorBanner: 'No pudimos enviar el mensaje. Intentá por WhatsApp o escribinos directo al email.',
      successTitle: '¡Mensaje recibido!',
      successBody: 'Te contactamos en menos de 24 horas.',
      fasterReply: '¿Querés respuesta más rápida?',
      continueWhatsapp: 'Seguir por WhatsApp',
      errName: 'El nombre es requerido',
      errEmail: 'El email es requerido',
      errEmailInvalid: 'Email inválido',
      errMessage: 'Contanos sobre tu proyecto',
      sidebarWhatsappLabel: 'WhatsApp',
      sidebarWhatsappTitle: 'Chatear ahora',
      sidebarWhatsappSub: 'Respuesta en minutos',
      sidebarEmailLabel: 'Email',
      sidebarEmailSub: 'Respuesta < 24hs',
      sidebarSocialHeading: 'Redes',
      sidebarLocationHeading: 'Ubicación',
      sidebarLocation: 'Buenos Aires, Argentina 🇦🇷',
      sidebarLocationSub: 'Trabajamos con clientes de todo el mundo.',
      whatsappPrefill: (name, company, service, message) =>
        `Hola! Soy ${name || '...'}${company ? ` de ${company}` : ''}. Me interesa consultar sobre ${service || 'un proyecto'}. ${message ? `\n\n${message}` : ''}`,
    },
    servicesOverview: {
      badge: 'Lo que hacemos',
      titleA: 'Servicios',
      titleB: 'a medida',
      subtitle: 'Cada servicio resuelve un problema concreto. Sin paquetes genéricos, sin promesas vacías. Solo lo que tu proyecto necesita para funcionar bien.',
      moreLabel: 'más',
      viewFull: 'Ver servicio completo',
    },
  },

  en: {
    nav: {
      home: 'Home',
      portfolio: 'Portfolio',
      about: 'About',
      blog: 'Blog',
      contact: 'Contact',
      services: 'Services',
      seeAll: 'See all services',
      seeAllShort: 'See all →',
      talk: "Let's talk",
      talkArrow: "Let's talk →",
    },
    footer: {
      tagline: 'Independent digital studio. We build web experiences with premium design and modern technology for projects worth standing out.',
      servicesHeading: 'Services',
      studioHeading: 'Studio',
      rights: 'All rights reserved.',
      madeIn: 'Designed and built in Argentina 🇦🇷',
    },
    contact: {
      badge: 'Contact',
      titleA: "Tell us about your",
      titleB: 'project',
      subtitle: "No endless forms, no long waits. We reply within 24 hours.",
      formTitle: 'Send us a message',
      fieldName: 'Name *',
      fieldNamePh: 'Your name',
      fieldEmail: 'Email *',
      fieldEmailPh: 'you@email.com',
      fieldCompany: 'Company / Project',
      fieldCompanyPh: 'Your company or project name',
      fieldService: 'What do you need?',
      serviceSelect: 'Select a service',
      serviceOptions: ['Web Design', 'Ecommerce', 'Web System', 'Automation', 'Web Maintenance', 'Other'],
      fieldMessage: 'Tell us about your project *',
      fieldMessagePh: "What you want to build, what stage you're at, what result you expect...",
      sendBtn: 'Send message',
      sending: 'Sending...',
      whatsappBtn: 'WhatsApp',
      whatsappHint: 'The WhatsApp button opens a chat pre-filled with your details.',
      errorBanner: "We couldn't send your message. Try WhatsApp or email us directly.",
      successTitle: 'Message received!',
      successBody: "We'll get back to you within 24 hours.",
      fasterReply: 'Want a faster reply?',
      continueWhatsapp: 'Continue on WhatsApp',
      errName: 'Name is required',
      errEmail: 'Email is required',
      errEmailInvalid: 'Invalid email',
      errMessage: 'Tell us about your project',
      sidebarWhatsappLabel: 'WhatsApp',
      sidebarWhatsappTitle: 'Chat now',
      sidebarWhatsappSub: 'Reply within minutes',
      sidebarEmailLabel: 'Email',
      sidebarEmailSub: 'Reply < 24h',
      sidebarSocialHeading: 'Social',
      sidebarLocationHeading: 'Location',
      sidebarLocation: 'Buenos Aires, Argentina 🇦🇷',
      sidebarLocationSub: 'We work with clients worldwide.',
      whatsappPrefill: (name, company, service, message) =>
        `Hi! I'm ${name || '...'}${company ? ` from ${company}` : ''}. I'm interested in ${service || 'a project'}. ${message ? `\n\n${message}` : ''}`,
    },
    servicesOverview: {
      badge: 'What we do',
      titleA: 'Services',
      titleB: 'built for you',
      subtitle: "Every service solves a real problem. No generic packages, no empty promises. Just what your project needs to actually work.",
      moreLabel: 'more',
      viewFull: 'View full service',
    },
  },
}

export function t(lang, path) {
  const keys = path.split('.')
  let node = ui[lang] || ui.es
  for (const k of keys) node = node?.[k]
  if (node === undefined) {
    // Fallback a español si falta la clave en inglés
    let fallback = ui.es
    for (const k of keys) fallback = fallback?.[k]
    return fallback ?? path
  }
  return node
}
